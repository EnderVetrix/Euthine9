By Graham Eibel
-----------------------
Arrows = move
Equals = Exit Game
s = Shield
f = Fire
e = (Not Implemented)
NOTE: The High Score File is hidden so no one can cheat!